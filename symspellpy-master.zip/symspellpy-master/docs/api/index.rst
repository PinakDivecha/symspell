============
API Overview
============

Modules
=======

.. only:: html

.. toctree::
   :maxdepth: 2

   helpers.rst
   editdistance.rst
   symspellpy.rst
