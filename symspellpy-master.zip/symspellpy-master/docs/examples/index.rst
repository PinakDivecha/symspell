========
Examples
========

.. only:: html

.. toctree::
    :maxdepth: 2

    dictionary.rst
    lookup.rst
    lookup_compound.rst
    word_segmentation.rst
